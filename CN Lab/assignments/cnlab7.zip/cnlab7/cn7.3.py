import random
import time

# Constants
TIMEOUT = 2
WINDOW_SIZE = 4  # For Selective Repeat
MAX_RETRIES = 5  # Max retries before skipping

def send_packet_sr(packet, seq_num):
    print(f"Sending packet {seq_num}: {packet}")

def receive_ack_sr(seq_num):
    if random.random() > 0.8:  # Simulate 20% chance of ACK loss
        print(f"ACK lost for packet {seq_num}")
        return False
    return True

def selective_repeat_protocol(data):
    print("\n--- Selective Repeat Protocol ---")
    base = 0
    next_seq_num = 0
    window = [None] * WINDOW_SIZE
    acked = [False] * len(data)
    retries = [0] * len(data)  # Track retries for each packet
    
    while base < len(data):
        # Send packets in the current window
        for i in range(WINDOW_SIZE):
            if next_seq_num < len(data) and not acked[next_seq_num]:
                send_packet_sr(data[next_seq_num], next_seq_num)
                next_seq_num += 1

        # Check for acknowledgments and retransmit if necessary
        for i in range(base, min(base + WINDOW_SIZE, len(data))):
            if not acked[i]:
                if receive_ack_sr(i):
                    print(f"ACK received for packet {i}")
                    acked[i] = True
                    retries[i] = 0  # Reset retries when successful
                else:
                    retries[i] += 1
                    if retries[i] >= MAX_RETRIES:
                        print(f"Max retries reached for packet {i}. Skipping.")
                        acked[i] = True  # Mark it as done to avoid infinite retries
                    else:
                        print(f"Retransmitting packet {i}")
                        send_packet_sr(data[i], i)

        # Slide the window
        while base < len(data) and acked[base]:
            base += 1

# Sample data (Packets)
data = ["Packet1", "Packet2", "Packet3", "Packet4", "Packet5"]

# Run protocol
selective_repeat_protocol(data)

