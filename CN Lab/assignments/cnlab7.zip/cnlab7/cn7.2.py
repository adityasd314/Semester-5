import random
import time

# Constants
TIMEOUT = 2
WINDOW_SIZE = 4  # For Go-Back-N
MAX_RETRIES = 5  # Max retries before skipping

def send_window(data, base, window_size):
    print(f"Sending window from {base} to {min(base + window_size, len(data)) - 1}")
    for i in range(base, min(base + window_size, len(data))):
        print(f"  Sending packet {i}: {data[i]}")

def receive_ack_gbn():
    # Simulate 20% chance of ACK loss
    if random.random() > 0.8:
        print("  ACK lost.")
        return None
    # Return a random ACK within the window size
    return random.randint(0, WINDOW_SIZE - 1)

def go_back_n_protocol(data):
    print("\n--- Go-Back-N Protocol ---")
    base = 0
    next_seq_num = 0
    retries = 0
    while base < len(data):
        # Send packets in the current window
        send_window(data, base, WINDOW_SIZE)
        
        # Wait for ACK and handle retransmissions
        ack_received = False
        while not ack_received and retries < MAX_RETRIES:
            ack = receive_ack_gbn()
            if ack is not None and base <= ack < base + WINDOW_SIZE:
                print(f"  ACK received for packet {ack}")
                base = ack + 1
                retries = 0  # Reset retries when successful
                ack_received = True
            else:
                retries += 1
                print(f"  Timeout, retransmitting from base {base} (Retry {retries})")
                send_window(data, base, WINDOW_SIZE)
        
        if retries >= MAX_RETRIES:
            print(f"  Max retries reached, skipping from base {base}")
            base += 1
            retries = 0  # Reset retries to continue

# Sample data (Packets)
data = ["Packet1", "Packet2", "Packet3", "Packet4", "Packet5"]

# Run protocol
go_back_n_protocol(data)

