import random
import time

# Constants
TIMEOUT = 2
MAX_RETRIES = 5  # Max retries before skipping
MAX_SEQ_NUM = 1  # For Stop and Wait, sequence number 0 or 1

def send_packet(packet, seq_num):
    print(f"Sending packet {seq_num}: {packet}")

def receive_ack():
    if random.random() > 0.8:  # Simulate 20% chance of ACK loss
        print("ACK lost.")
        return None
    return 1

def stop_and_wait_protocol(data):
    print("\n--- Stop-and-Wait Protocol ---")
    seq_num = 0
    for packet in data:
        ack_received = False
        retries = 0
        while not ack_received and retries < MAX_RETRIES:
            send_packet(packet, seq_num)
            start_time = time.time()
            while time.time() - start_time < TIMEOUT:
                ack = receive_ack()
                if ack is not None:
                    print(f"ACK received for packet {seq_num}")
                    seq_num = (seq_num + 1) % 2  # Alternate between 0 and 1
                    ack_received = True
                    break
            if not ack_received:
                retries += 1
                print(f"Timeout for packet {seq_num}, retransmitting... (Retry {retries})")
        if retries == MAX_RETRIES:
            print(f"Max retries reached for packet {seq_num}. Moving to next packet.")

# Sample data (Packets)
data = ["Packet1", "Packet2", "Packet3"]  # Reduced packet count

# Run protocol
stop_and_wait_protocol(data)

